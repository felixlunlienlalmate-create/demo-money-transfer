#!/usr/bin/env bash
set -e
flutter create demo_money_transfer
cp pubspec.yaml demo_money_transfer/pubspec.yaml
cp -r lib demo_money_transfer/
cp android/app/src/main/AndroidManifest.xml demo_money_transfer/android/app/src/main/AndroidManifest.xml
cd demo_money_transfer
flutter pub get
echo "Project ready. Run: flutter run"
