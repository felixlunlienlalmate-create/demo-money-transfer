# Demo Money Transfer — Android APK Build

This is a **demo/simulation** payment app. It does not connect to banks, UPI,
cards, wallets, or real payment processors.

## Build online with GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository.
3. Commit/push to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK**.
6. Run the workflow.
7. When it finishes, open the workflow run and download the artifact
   named `demo-money-release-apk`.
8. Inside the downloaded artifact is `app-release.apk`.

The workflow uses Flutter 3.44.7 and runs `flutter build apk --release`.
The generated APK is an unsigned release artifact suitable for local testing.
For Play Store distribution, configure proper app signing.

## App behavior

- Fictional starting balance: ₹10,000
- Demo transfers only
- Local transaction history
- Local Android notification marked DEMO
- No real payment APIs
- Persistent local storage
- Reset demo account

## Important

The app's "recipient notification" is local to the device running the demo.
It does not notify another person's phone and does not claim that real money
was transferred.
