import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  runApp(const DemoMoneyApp());
}

class DemoMoneyApp extends StatelessWidget {
  const DemoMoneyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Demo Money',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class NotificationService {
  static final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await plugin.initialize(settings);

    final androidImpl = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.requestNotificationsPermission();
  }

  static Future<void> showReceived({
    required String recipient,
    required double amount,
  }) async {
    const details = AndroidNotificationDetails(
      'demo_received',
      'Demo payments',
      channelDescription: 'Notifications for simulated money transfers',
      importance: Importance.high,
      priority: Priority.high,
    );

    await plugin.show(
      DateTime.now().millisecondsSinceEpoch.remainder(1000000),
      'Money received (DEMO)',
      '₹${amount.toStringAsFixed(2)} has been received by $recipient (demo).',
      const NotificationDetails(android: details),
    );
  }
}

class DemoTransaction {
  final String id;
  final String recipient;
  final String demoId;
  final double amount;
  final DateTime time;

  DemoTransaction({
    required this.id,
    required this.recipient,
    required this.demoId,
    required this.amount,
    required this.time,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'recipient': recipient,
        'demoId': demoId,
        'amount': amount,
        'time': time.toIso8601String(),
      };

  factory DemoTransaction.fromJson(Map<String, dynamic> json) {
    return DemoTransaction(
      id: json['id'] as String,
      recipient: json['recipient'] as String,
      demoId: json['demoId'] as String,
      amount: (json['amount'] as num).toDouble(),
      time: DateTime.parse(json['time'] as String),
    );
  }
}

class DemoStore extends ChangeNotifier {
  static const _balanceKey = 'demo_balance';
  static const _txKey = 'demo_transactions';

  double balance = 10000;
  List<DemoTransaction> transactions = [];

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    balance = prefs.getDouble(_balanceKey) ?? 10000;
    final raw = prefs.getStringList(_txKey) ?? [];
    transactions = raw
        .map((e) => DemoTransaction.fromJson(jsonDecode(e)))
        .toList()
      ..sort((a, b) => b.time.compareTo(a.time));
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_balanceKey, balance);
    await prefs.setStringList(
      _txKey,
      transactions.map((e) => jsonEncode(e.toJson())).toList(),
    );
  }

  Future<void> send({
    required String recipient,
    required String demoId,
    required double amount,
  }) async {
    if (amount <= 0) {
      throw Exception('Enter an amount greater than ₹0.');
    }
    if (amount > balance) {
      throw Exception('Demo balance is too low.');
    }

    // This is deliberately simulated: no bank/UPI/payment API is called.
    balance -= amount;

    final tx = DemoTransaction(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      recipient: recipient,
      demoId: demoId,
      amount: amount,
      time: DateTime.now(),
    );

    transactions.insert(0, tx);
    await save();
    notifyListeners();

    // Local demo notification. It does not send money or contact a real recipient.
    await NotificationService.showReceived(
      recipient: recipient,
      amount: amount,
    );
  }

  Future<void> reset() async {
    balance = 10000;
    transactions = [];
    await save();
    notifyListeners();
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final store = DemoStore();

  @override
  void initState() {
    super.initState();
    store.load();
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  String money(double value) => '₹${value.toStringAsFixed(2)}';

  Future<void> openSend() async {
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => SendSheet(store: store),
    );

    if (result == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Demo transfer completed. No real money was moved.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Demo Money'),
            actions: [
              IconButton(
                tooltip: 'Reset demo',
                onPressed: () async {
                  await store.reset();
                  if (!mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Demo account reset.')),
                  );
                },
                icon: const Icon(Icons.refresh),
              ),
            ],
          ),
          body: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.amber.shade50,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.amber.shade300),
                  ),
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.info_outline),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'DEMO / SIMULATION ONLY\n'
                          'This app never connects to a bank, UPI, card network, or real payment service.',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Demo balance'),
                        const SizedBox(height: 6),
                        Text(
                          money(store.balance),
                          style: Theme.of(context)
                              .textTheme
                              .displaySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: openSend,
                          icon: const Icon(Icons.send),
                          label: const Text('Send demo money'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'Recent demo transfers',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 8),
                if (store.transactions.isEmpty)
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Text('No demo transfers yet.'),
                    ),
                  )
                else
                  ...store.transactions.map(
                    (tx) => Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.person),
                        ),
                        title: Text(tx.recipient),
                        subtitle: Text(
                          '${tx.demoId}\n${formatDate(tx.time)}',
                        ),
                        isThreeLine: true,
                        trailing: Text(
                          '- ${money(tx.amount)}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  static String formatDate(DateTime dt) {
    final local = dt.toLocal();
    final h = local.hour % 12 == 0 ? 12 : local.hour % 12;
    final m = local.minute.toString().padLeft(2, '0');
    final suffix = local.hour >= 12 ? 'PM' : 'AM';
    return '${local.day.toString().padLeft(2, '0')}/'
        '${local.month.toString().padLeft(2, '0')}/${local.year} '
        '$h:$m $suffix';
  }
}

class SendSheet extends StatefulWidget {
  final DemoStore store;

  const SendSheet({super.key, required this.store});

  @override
  State<SendSheet> createState() => _SendSheetState();
}

class _SendSheetState extends State<SendSheet> {
  final name = TextEditingController();
  final demoId = TextEditingController();
  final amount = TextEditingController();

  bool sending = false;

  @override
  void dispose() {
    name.dispose();
    demoId.dispose();
    amount.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    FocusScope.of(context).unfocus();

    final recipient = name.text.trim();
    final id = demoId.text.trim();
    final value = double.tryParse(amount.text.trim());

    if (recipient.isEmpty || id.isEmpty || value == null) {
      showError('Fill in recipient, demo ID, and amount.');
      return;
    }

    setState(() => sending = true);

    try {
      await widget.store.send(
        recipient: recipient,
        demoId: id,
        amount: value,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) showError(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  void showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Send demo money',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            const Text(
              'The balance and notification are simulated locally. '
              'Nothing is deducted from a real account.',
            ),
            const SizedBox(height: 18),
            TextField(
              controller: name,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Recipient name',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: demoId,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Demo recipient ID',
                hintText: 'alex@demo',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: amount,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Amount',
                prefixText: '₹ ',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: sending ? null : submit,
              icon: sending
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.check),
              label: Text(sending ? 'Sending demo...' : 'Send demo money'),
            ),
          ],
        ),
      ),
    );
  }
}
